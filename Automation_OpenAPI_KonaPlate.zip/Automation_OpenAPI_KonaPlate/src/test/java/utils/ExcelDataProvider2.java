package utils;

import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.Utils;

public class ExcelDataProvider2 {
	
	static WebDriver driver = null;
	
	@BeforeTest
	public void setUpTest() {
		
		String projectPath = System.getProperty("user.dir");
	    System.setProperty("webdriver.chrome.driver", projectPath+"\\drivers\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
    @Test 
	public void test1() throws Exception {
		//System.out.println(username+ " | "+password);
		
		/*driver.get("http://orangehrm.qedgetech.com/symfony/web/index.php/auth/login");
		driver.findElement(By.id("txtUsername")).sendKeys(username);
		driver.findElement(By.id("txtPassword")).sendKeys(password);*/
		
        driver.get("https://dev-qa.konapay.net:10444/");
    	
    	Thread.sleep(5000);
    	
		driver.manage().window().maximize();
		
		Thread.sleep(5000);
		
		
		
		//driver.findElement(By.xpath("/html/body/div[1]/header/div/div[3]/svg")).click();
		
		driver.findElement(By.xpath("/html/body/div[1]/header/div/button")).click();
		//driver.findElement(By.name("btnK")).click();
		//driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[2]/div/div[2]/form/div[1]/div/div")).click();
		
		Thread.sleep(5000);
		
		
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/div[2]/form/div[2]/div/div[2]/div/input")).sendKeys("rakib2@dispostable.com");
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/div[2]/form/div[3]/div/div[2]/div/input")).sendKeys("Enam@112");
		
		Thread.sleep(5000);
		
		Utils.CaptureScreenshot(driver, "MyScreenshot_image11.png");
		
		
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/div[2]/form/div[5]/button")).click();
		
		Thread.sleep(5000);
		
		
		
		FileInputStream fileObj = new FileInputStream("C:\\Users\\enamul.haque\\eclipse-workspace\\SeleniumJavaFramework\\excel\\projectCreation.xlsx");
		XSSFWorkbook workbookObj = new XSSFWorkbook (fileObj);
		XSSFSheet sheetObj = workbookObj.getSheet ("Sheet1");
		int rcount=sheetObj.getLastRowNum();
		
		
		
		int r;
		
		for (r=0; r<=rcount; r++) 
		
		{
			
			
			driver.get("https://dev-qa.konapay.net:10444/dashboard");
	    	
	    	Thread.sleep(5000);
	    	
			driver.manage().window().maximize();
			
			Thread.sleep(5000);
			
			//clicking on my dashboard
			//driver.findElement(By.xpath("/html/body/div[1]/header/div/button")).click();
			
			//Thread.sleep(5000);
			
			//scroll-down
			//JavascriptExecutor jse = (JavascriptExecutor)driver;
			//jse.executeScript("window.scrollBy(0,700)");
			//jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
			
			Thread.sleep(5000);
			
			
			if (r==0)
				
		{
				
			try {
			    
				//clicking on 'Create Project'
				driver.findElement(By.xpath("/html/body/div/div[2]/div[3]/div[2]/div[2]/button")).click();
				
				Thread.sleep(5000);
				
			}
			
			
			catch (Exception e) 
			{
			
			    //clicking on 'Create Project'
                driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div[2]/div[1]/button")).click();
				Thread.sleep(5000);	
			
			}
		}
			
			if (r>=1)
			{
				driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div[2]/div[1]/button")).click();
				Thread.sleep(5000);	
			}
			
			driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/form/div[1]/div[2]/div/div[2]/div/input")).sendKeys(sheetObj.getRow(r).getCell(0).getStringCellValue());
			Thread.sleep(5000);
			
			driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/form/div[1]/div[3]/div/div[2]/div/textarea[1]")).sendKeys(sheetObj.getRow(r).getCell(1).getStringCellValue());
			Thread.sleep(5000);
			
			//scroll-down
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			//jse.executeScript("window.scrollBy(0,700)");
			jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
			
			
			//select dropdown icon
			driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/form/div[2]/div/div[2]/div/div[2]/div[1]/div/div")).click();
			
			Thread.sleep(5000);
			
			//selecting package 'Debit Card'
			if (r==0)
			{
			driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/form/div[2]/div/div[2]/div/div[2]/div[2]/div[3]/div/p")).click();
			
			Thread.sleep(5000);
			} 
			
			if (r==1)
			{
			driver.findElement(By.xpath("/html/body/div/div[2]/div[3]/div/form/div[2]/div/div[2]/div/div[2]/div[2]/div[4]/div/p")).click();
			
			Thread.sleep(5000);
			}
			
			if (r>=2)
			{
			driver.findElement(By.xpath("/html/body/div/div[2]/div[3]/div/form/div[2]/div/div[2]/div/div[2]/div[2]/div[10]/div/p")).click();
			
			Thread.sleep(5000);
			} 
			
			//driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/form/div[2]/div/div[3]/div[2]/div[2]/div[1]/div[1]/div/svg/path")).click();
			
			//Thread.sleep(5000);
			
			//driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/form/div[2]/div/div[3]/div[2]/div[2]/div[1]/div[1]/div/svg/path")).click();
			
			//Thread.sleep(5000);
			
			//Create project
			driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/form/div[3]/button[1]")).click();
			Thread.sleep(5000);
			
			test.Utils.CaptureScreenshot(driver, "MyScreenshot_image22.png");
				
				
			}
		
		
		
		
		try {
			
			boolean a = driver.findElement(By.xpath("/html/body/div[67]/div[3]/div/div/div[1]/p")).isDisplayed();
			
			if (a) 
			{
			
			System.out.println("Project limit already exceded!");
			
			Thread.sleep(5000);
			
			driver.findElement(By.xpath("/html/body/div[67]/div[3]/div/div/div[2]/button")).click();
			
			Thread.sleep(5000);
			
			driver.get("https://dev-qa.konapay.net:10444/dashboard");
			
			//clicking on dashboard
			//driver.findElement(By.xpath("/html/body/div[1]/header/div/button")).click();
			
			Thread.sleep(5000);
			
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,400)");
			
			Thread.sleep(5000);
			
			}
			
		}
		
		
		
		
		
		catch (Exception e) 
		{
			
			//scroll-down
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
			
			Thread.sleep(5000);

			
			System.out.println("Expected number of projects have been already created!");
			
			Thread.sleep(5000);
			
			//clicking on dashboard
			//driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/div/div/div[7]/button")).click();
			
            driver.get("https://dev-qa.konapay.net:10444/dashboard");
			
			//clicking on dashboard
			//driver.findElement(By.xpath("/html/body/div[1]/header/div/button")).click();
			
			Thread.sleep(5000);
			
			JavascriptExecutor jse2 = (JavascriptExecutor)driver;
			jse2.executeScript("window.scrollBy(0,400)");
			
			Thread.sleep(5000);
			
		}
			
			
	}
		
		
	
    
    
   /* @Test
    public void contactUs() throws InterruptedException {
    	
    	//driver.get("https://dev-qa.konapay.net:10444/resources/contact-us");
    	
    	
    	//clicking on Resources
    	driver.findElement(By.xpath("/html/body/div[1]/header/div/nav/ul/li[3]/a")).click();
    	
    	Thread.sleep(5000);
    	
    	//clicking on ContactUs from DropDown list
    	driver.findElement(By.xpath("/html/body/div[1]/header/div/nav/ul/li[3]/ul/li[3]/a")).click();
    	
    	Thread.sleep(5000);
    	
    	//clear the name 
    	//driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(3) > div:nth-child(1) > div:nth-child(3) > form:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > input:nth-child(1)")).clear();
    	
    	//Fill up name field
    	driver.findElement(By.xpath("/html/body/div/div[2]/div[3]/div/div[2]/form/div[1]/div[1]/div/div[2]/div/input")).sendKeys("Tamim");
    	
    	Thread.sleep(5000);
    }*/
    
    
    
    /*@Test
    public void LogOut_ContactUs() throws Exception {
    	
    	driver.findElement(By.xpath("/html/body/div/header/div/a/span/img")).click();
    	
    	//LogOut
    	driver.findElement(By.xpath("/html/body/div[1]/header/div/button")).click();
    	driver.findElement(By.xpath("/html/body/div[1]/header/div/button/div/div/ul/li[2]/span")).click();
    	
    	
    	//clicking on Resources after logging out
    	driver.findElement(By.xpath("/html/body/div[1]/header/div/nav/ul/li[3]/a")).click();
    	
    	Thread.sleep(5000);
    	
    	//clicking on ContactUs from DropDown list
    	driver.findElement(By.xpath("/html/body/div[1]/header/div/nav/ul/li[3]/ul/li[3]/a")).click();
    	
    	Thread.sleep(5000);
    	
    	//clear the name 
    	//driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(3) > div:nth-child(1) > div:nth-child(3) > form:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > input:nth-child(1)")).clear();
    	
    	//Fill up name field
    	//driver.findElement(By.xpath("/html/body/div/div[2]/div[3]/div/div[2]/form/div[1]/div[1]/div/div[2]/div/input")).sendKeys("Tamim");
    	
    	//Fill phone number field
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div[2]/form/div[1]/div[3]/div/div[2]/div/input")).sendKeys("01675308877");
    	
    	Thread.sleep(5000);
    	
    	//Fill Title field
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div[2]/form/div[1]/div[7]/div/div[2]/div/input")).sendKeys("Title for automation");
    	
    	Thread.sleep(5000);
    	
    	//Fill message field
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div[2]/form/div[1]/div[8]/div/div[2]/div/textarea[1]")).sendKeys("Message for automation");
    	
    	Thread.sleep(5000);
    	
    	
    	//click on Contact us
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div[2]/form/div[2]/button")).click();
    	
    }*/

}
