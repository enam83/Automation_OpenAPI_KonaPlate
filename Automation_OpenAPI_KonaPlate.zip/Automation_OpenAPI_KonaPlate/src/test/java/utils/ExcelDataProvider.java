package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ExcelDataProvider {
	
	static WebDriver driver = null;
	
	@BeforeTest
	public void setUpTest() {
		
		String projectPath = System.getProperty("user.dir");
	    System.setProperty("webdriver.chrome.driver", projectPath+"\\drivers\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
    @Test (dataProvider="test1data")
	public void test1(String username, String password) throws Exception {
		System.out.println(username+ " | "+password);
		
		/*driver.get("http://orangehrm.qedgetech.com/symfony/web/index.php/auth/login");
		driver.findElement(By.id("txtUsername")).sendKeys(username);
		driver.findElement(By.id("txtPassword")).sendKeys(password);*/
		
        driver.get("https://dev-qa.konapay.net:10444/");
    	
    	Thread.sleep(5000);
    	
		driver.manage().window().maximize();
		
		Thread.sleep(5000);
		
		
		
		//driver.findElement(By.xpath("/html/body/div[1]/header/div/div[3]/svg")).click();
		
		driver.findElement(By.xpath("/html/body/div[1]/header/div/button")).click();
		//driver.findElement(By.name("btnK")).click();
		//driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[2]/div/div[2]/form/div[1]/div/div")).click();
		
		Thread.sleep(5000);
		
		
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/div[2]/form/div[2]/div/div[2]/div/input")).sendKeys(username);
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/div[2]/form/div[3]/div/div[2]/div/input")).sendKeys(password);
		
		Thread.sleep(5000);
		
		
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/div[2]/form/div[5]/button")).click();
		
		Thread.sleep(5000);
		
		
		
		//clicking on my dashboard
		driver.findElement(By.xpath("/html/body/div[1]/header/div/button")).click();
		
		Thread.sleep(5000);
		
		//clicking on 'Create Project'
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div[2]/div[1]/button")).click();
		
		Thread.sleep(5000);
		
		
		//select project name
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/form/div[1]/div[2]/div/div[2]/div/input")).sendKeys("Project created for automation");
		Thread.sleep(5000);
		
		//select project description
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/form/div[1]/div[3]/div/div[2]/div/textarea[1]")).sendKeys("Project description");
		
		Thread.sleep(5000);
		
		
		//select dropdown icon
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/form/div[2]/div/div[2]/div/div[2]/div[1]/div/div")).click();
		
		Thread.sleep(5000);
		
		//selecting package 'Pre-paid Card'
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/form/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/div/p")).click();
		
		Thread.sleep(5000);
		
		
		//Create project
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/form/div[3]/button[1]")).click();
		
		
		
		Thread.sleep(5000);
		
	}
	
	
	@DataProvider(name = "test1data")
	public Object[][] getData() {
		String excelPath = "C:\\Users\\enamul.haque\\eclipse-workspace\\SeleniumJavaFramework\\excel\\data.xlsx";
		Object data[][] = testData(excelPath, "Sheet1");
		return data;
	}
	
	
	
	
	public Object[][] testData(String excelPath, String sheetName) {
		
		ExcelUtils excel = new ExcelUtils(excelPath, sheetName);
		
		int rowCount = excel.getRowCount();
		int colCount = excel.getColCount();
		
		Object data[][] = new Object [rowCount-1][colCount];
		
		for(int i=1; i<rowCount; i++)
		{
			for(int j=0; j<colCount; j++) {
				
				String cellData = excel.getCellDataString(i, j);
				//System.out.print(cellData+" | ");
				data[i-1][j] = cellData;
				
			}
			//System.out.println();
			
		}
		return data;
	}

}
