package test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Open_Api_SignUp {
	
	WebDriver driver = null;
	
	
	@BeforeTest
	public void setUpTest() {
		
		String projectPath = System.getProperty("user.dir");
	    System.setProperty("webdriver.chrome.driver", projectPath+"\\drivers\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	
    @Test
	public void googleSearch() throws InterruptedException {
		
		driver.get("https://dev-qa.konapay.net:10444");
		
		Thread.sleep(5000);
		
		driver.manage().window().maximize();
		
		Thread.sleep(5000);
		
		//*[@id="__next"]/header/div/div[3]/svg/path
		
		
		//driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div[3]/svg/path")).click();
		
		
		
		driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/button")).click();
		
		Thread.sleep(5000);
		
		//driver.findElement(By.name("btnK")).click();
		driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[2]/div/div[2]/form/div[1]/div/div")).click();
		
		driver.findElement(By.name("name")).sendKeys("Riasat1");
		driver.findElement(By.name("email")).sendKeys("Riasat1@dispostable.com");
		driver.findElement(By.name("companyName")).sendKeys("KSL");
		driver.findElement(By.name("password")).sendKeys("Enam@123");
		driver.findElement(By.name("confirmPassword")).sendKeys("Enam@123");
		
		Thread.sleep(5000);
		
		//driver.findElement(By.xpath("//*[@id=\"recaptcha-anchor\"]/div[1]")).click();
		
		//Thread.sleep(5000);
		
		driver.findElement(By.name("readAndAgree")).click();
		driver.findElement(By.name("subscribed")).click();
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/div/form/div[8]/button")).click();
		
		
		
		
		
		
		//Thread.sleep(5000);
			
	}
	
	
    @AfterTest
	public void tearDownTest() {
		
        //driver.close();
		driver.quit();
		System.out.println("Test completed");
		
	}

}
