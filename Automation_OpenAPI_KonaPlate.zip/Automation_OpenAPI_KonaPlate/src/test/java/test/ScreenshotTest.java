package test;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ScreenshotTest {
	
	static WebDriver driver = null;
    
	@Test
	public static void main(String[] args) throws InterruptedException, IOException {
		
		
			
			String projectPath = System.getProperty("user.dir");
		    System.setProperty("webdriver.chrome.driver", projectPath+"\\drivers\\chromedriver\\chromedriver.exe");
			driver = new ChromeDriver();
			
			driver.get("https://dev-qa.konapay.net:10444/");
			Utils.CaptureScreenshot(driver, "MyScreenshot_image1.png");
			Thread.sleep(5000);
			
	    	driver.manage().window().maximize();
			Thread.sleep(5000);
			
			driver.findElement(By.xpath("/html/body/div[1]/header/div/button")).click();
			Utils.CaptureScreenshot(driver, "MyScreenshot_image2.jpg");
			Thread.sleep(5000);
			
			driver.quit();
			
		
		

	}

}
