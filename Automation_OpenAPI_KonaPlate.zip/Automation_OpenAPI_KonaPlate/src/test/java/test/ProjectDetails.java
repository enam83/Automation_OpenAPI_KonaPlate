package test;

import static org.testng.Assert.assertTrue;

import java.io.FileInputStream;
import java.time.Duration;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.Utils;

public class ProjectDetails {
	
	static WebDriver driver = null;
	
	@BeforeTest
	public void setUpTest() {
		
		String projectPath = System.getProperty("user.dir");
	    System.setProperty("webdriver.chrome.driver", projectPath+"\\drivers\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
    
	@Test 
	public void test1() throws Exception {
		//System.out.println(username+ " | "+password);
		
		/*driver.get("http://orangehrm.qedgetech.com/symfony/web/index.php/auth/login");
		driver.findElement(By.id("txtUsername")).sendKeys(username);
		driver.findElement(By.id("txtPassword")).sendKeys(password);*/
    	
    	//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	
    	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
        driver.get("https://dev-qa.konapay.net:10444/");
    	
    	Thread.sleep(5000);
    	
		driver.manage().window().maximize();
		
		Thread.sleep(5000);
		
		
		
		//driver.findElement(By.xpath("/html/body/div[1]/header/div/div[3]/svg")).click();
		
		driver.findElement(By.xpath("/html/body/div[1]/header/div/button")).click();
		//driver.findElement(By.name("btnK")).click();
		//driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[2]/div/div[2]/form/div[1]/div/div")).click();
		
		Thread.sleep(3000);
		
		
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/div[2]/form/div[2]/div/div[2]/div/input")).sendKeys("rakib2@dispostable.com");
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/div[2]/form/div[3]/div/div[2]/div/input")).sendKeys("Enam@112");
		
		Thread.sleep(3000);
		
		
        driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/div[2]/form/div[5]/button")).click();
		
		Thread.sleep(3000);
		
		
		driver.get("https://dev-qa.konapay.net:10444/dashboard");
		
		Thread.sleep(3000);
		
		
		
			
		//scroll-down
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,700)");
		//jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
			
			
		//click on project	
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div[2]/div[2]/div[1]/table/tbody/tr[1]/td[1]/div/p/a")).click();
			
		Thread.sleep(3000);
		
		
		//clicking on summary
		//driver.findElement(By.cssSelector("#__next > div.mainwrp.MuiBox-root.css-0 > div.MuiContainer-root.MuiContainer-maxWidthLg.css-1vn9tty > div.MuiBox-root.css-1dofi3l > div.MuiBox-root.css-ltkxuh > div.MuiBox-root.css-10d9ljm > div:nth-child(1) > div > p")).click();
		
		
		//Thread.sleep(5000);
		
		
		//scroll-down
		JavascriptExecutor jse2 = (JavascriptExecutor)driver;
		jse2.executeScript("window.scrollBy(0,1200)");
		//jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		
		Thread.sleep(3000);
		
		//driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div[2]/div[2]/div/div[5]/div/div/div/div[2]/div[1]/div/svg/path")).click();
		driver.findElement(By.cssSelector(".project-api-table-cell.MuiBox-root.css-wrexly .project-api-table-cell-inner.MuiBox-root.css-xs1kls path")).click();

		Thread.sleep(3000);
		
		
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div[2]/div[2]/div/div[5]/div/div/div/div[3]/div/div/div[1]/div[4]/div/a")).click();
		Thread.sleep(3000);
		
		//ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		
		Set<String> handles = driver.getWindowHandles();
		
		Iterator it = handles.iterator();
		
		String parentid = (String) it.next();
		String childid = (String) it.next();
		
		driver.switchTo().window(childid);
		
		Thread.sleep(3000);
		
		assertTrue(driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div[1]/p")).isDisplayed());
		Thread.sleep(3000);
		
		driver.switchTo().window(parentid);
		Thread.sleep(3000);
		
		
		driver.findElement(By.cssSelector(".project-api-table-cell.MuiBox-root.css-wrexly .project-api-table-cell-inner.MuiBox-root.css-xs1kls path")).click();

		Thread.sleep(3000);
		
	    
		
		//clicking on credentials
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div[2]/div[1]/div[1]/div[2]/div/p")).click();
    	Thread.sleep(3000);
    	
    	//scroll-down
    	 JavascriptExecutor jse3 = (JavascriptExecutor)driver;
    	 jse3.executeScript("window.scrollBy(0,-300)");
    	 
    	 Thread.sleep(3000);
    	
    	
    	//Generate key
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div[2]/div[2]/div[2]/div/div[2]/button")).click();
    	Thread.sleep(3000);
    	
    	//click on generate key
    	driver.findElement(By.cssSelector(".MuiButtonBase-root.MuiButton-root.MuiButton-contained.MuiButton-containedPrimary.MuiButton-sizeMedium.MuiButton-containedSizeMedium.MuiButton-disableElevation.MuiButton-fullWidth.MuiButton-root.MuiButton-contained.MuiButton-containedPrimary.MuiButton-sizeMedium.MuiButton-containedSizeMedium.MuiButton-disableElevation.MuiButton-fullWidth.css-1x60fb2")).click();
    	
    	Thread.sleep(3000);
    	
    	
    }


	
		
    
}	
		
		
		
		
		
	
    
    
   
    

