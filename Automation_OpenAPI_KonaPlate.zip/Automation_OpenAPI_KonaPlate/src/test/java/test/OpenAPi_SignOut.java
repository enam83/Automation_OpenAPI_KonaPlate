package test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class OpenAPi_SignOut {
	
	WebDriver driver = null;
	
	
	@BeforeTest
	public void setUpTest() {
		
		String projectPath = System.getProperty("user.dir");
	    System.setProperty("webdriver.chrome.driver", projectPath+"\\drivers\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	
    @Test
	public void googleSearch() throws InterruptedException {
		
		driver.get("https://www.konaplate.com/en/dashboard");
		driver.manage().window().maximize();
		
		Thread.sleep(5000);
		
		
		
		
		//clickiing on Sign Out
		driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/button/div/div/ul/li[2]/span")).click();
		
		
		
			
	}
	
	
    @AfterTest
	public void tearDownTest() {
		
        //driver.close();
		driver.quit();
		System.out.println("Test completed");
		
	}

}
