package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
 
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
 
public class automateCaptchaInSelenium {
 
 
    public String username = "enamul283";
    public String accesskey = "dZJqLKJFolL4YgLLlisnpJDk8xrBHBeM1qOT3WcgpaOJL7cTXk";
    public static RemoteWebDriver driver = null;
    public String gridURL = "@hub.lambdatest.com/wd/hub";
 
    @BeforeClass
    public void setUp() throws Exception {
    	
    	String projectPath = System.getProperty("user.dir");
	    System.setProperty("webdriver.chrome.driver", projectPath+"\\drivers\\chromedriver\\chromedriver.exe");
	    
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("browserName", "chrome");
        capabilities.setCapability("version", "112.0.5615.49");
        capabilities.setCapability("platform", "win10"); // If this cap isn't specified, it will just get the any available one
        capabilities.setCapability("build", "CaptchaInSelenium");
        capabilities.setCapability("name", "TCaptchaInSeleniumSample");
        try {
            driver = new RemoteWebDriver(new URL("https://" + username + ":" + accesskey + gridURL), capabilities);
        } catch (MalformedURLException e) {
            System.out.println("Invalid grid URL");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        driver.get("https://dev-qa.konapay.net:10444/en/user/registration");
        
        driver.manage().window().maximize();
 
 
    }
 
    @Test
    public void manuallySolveCaptchaWithDelayInSelenium() {
        try {
            System.out.println("Let's start with fresh registration");
            
            /*WebElement username=driver.findElement(By.xpath("//input[@name='user']"));
            username.sendKeys("some_username_200");
 
            WebElement password=driver.findElement(By.xpath("//input[@name='passwd']"));
            password.sendKeys("SuperStrongP@ssw0rd");
 
            WebElement verifyPassword=driver.findElement(By.xpath("//input[@name='passwd2']"));
            verifyPassword.sendKeys("SuperStrongP@ssw0rd");
 
            WebElement email=driver.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("xyz@gmail.com");*/
            
            driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[2]/div/div[2]/form/div[1]/div/div")).click();
    		
    		driver.findElement(By.name("name")).sendKeys("Riasat1");
    		driver.findElement(By.name("email")).sendKeys("Riasat1@dispostable.com");
    		driver.findElement(By.name("companyName")).sendKeys("KSL");
    		driver.findElement(By.name("password")).sendKeys("Enam@123");
    		driver.findElement(By.name("confirmPassword")).sendKeys("Enam@123");
    		
    		Thread.sleep(5000);
    		
    		//driver.findElement(By.xpath("//*[@id=\"recaptcha-anchor\"]/div[1]")).click();
    		
    		//Thread.sleep(5000);
    		
    		
    		Thread.sleep(5000);
    		
    		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/div/form/div[8]/button")).click();
 
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));
            wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(
                    By.xpath("//iframe[starts-with(@name, 'a-') and starts-with(@src, 'https://www.google.com/recaptcha')]")));
           
             wait.until(ExpectedConditions.elementToBeClickable(
                        By.xpath("//*[@id=\"recaptcha-anchor\"]/div[1]"))).click();
 
            System.out.println("Clicked the checkbox");
            
            driver.findElement(By.name("readAndAgree")).click();
    		driver.findElement(By.name("subscribed")).click();
 
            wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//*[@id=\"__next\"]/div[2]/div[2]/div/div/form/div[8]/button"))).click();
 
            System.out.println("Clicked the sign up button");
            
            
 
        } catch (Exception e) {
 
        }
 
    }
 
 
    @AfterClass
    public void closeBrowser() {
        driver.close();
        Reporter.log("Closing the browser", true);
 
    }
 
}