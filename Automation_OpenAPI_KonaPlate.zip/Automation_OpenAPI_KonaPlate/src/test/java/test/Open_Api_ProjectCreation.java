package test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Open_Api_ProjectCreation {
	
	WebDriver driver = null;
	
	
	@BeforeTest
	public void setUpTest() {
		
		String projectPath = System.getProperty("user.dir");
	    System.setProperty("webdriver.chrome.driver", projectPath+"\\drivers\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	
    @Test
	public void googleSearch() throws InterruptedException {
		
		driver.get("https://www.konaplate.com/en/dashboard");
		driver.manage().window().maximize();
		
		Thread.sleep(5000);
		
		
		
		
		//clicking on my dashboard
		driver.findElement(By.xpath("/html/body/div[1]/header/div/button")).click();
		
		//clicking on 'Create Project'
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div[2]/div[1]/button")).click();
		
		
		//select project name & description
		driver.findElement(By.name("name")).sendKeys("Project created for automation");
		driver.findElement(By.name("desc")).sendKeys("Project description");
		
		driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[3]/div/form/div[2]/div/div[2]/div/div[2]/div[1]/div/div")).click();
		
		//selecting package 'Pre-paid Card'
		driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[3]/div/form/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/div/p")).click();
		
		
		//Create project
		driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[3]/div/form/div[3]/button[1]")).click();
		
		
		
		
		
		//Thread.sleep(5000);
			
	}
	
	
    @AfterTest
	public void tearDownTest() {
		
        //driver.close();
		driver.quit();
		System.out.println("Test completed");
		
	}

}
