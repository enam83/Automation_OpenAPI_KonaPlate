package test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNG_Demo {
	
	WebDriver driver = null;
	
	
	@BeforeTest
	public void setUpTest() {
		
		String projectPath = System.getProperty("user.dir");
	    System.setProperty("webdriver.chrome.driver", projectPath+"\\drivers\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	
    @Test
	public void googleSearch() throws InterruptedException {
		
		driver.get("https://google.com");
		driver.manage().window().maximize();
		
		Thread.sleep(5000);
		
		driver.findElement(By.id("APjFqb")).sendKeys("automation steps steps by step");
		//driver.findElement(By.name("btnK")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]")).click();
		
		//Thread.sleep(5000);
			
	}
	
	
    @AfterTest
	public void tearDownTest() {
		
        //driver.close();
		driver.quit();
		System.out.println("Test completed");
		
	}

}
