package test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pages.GoogleSearchPage;

public class GoogleSearchTest {
	
	private static WebDriver driver = null;
	
	public static void main(String[] args) throws InterruptedException {
		
		googleSearch();
		
	}
	
	
	public static void googleSearch() throws InterruptedException {
		
		String projectPath = System.getProperty("user.dir");
	    System.out.println (projectPath);
	      
		 
	    System.setProperty("webdriver.chrome.driver", projectPath+"\\drivers\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.get("https://google.com");
		
		driver.manage().window().maximize();
		
		Thread.sleep(5000);
		
		//driver.findElement(By.id("APjFqb")).sendKeys("automation step step by step");
		
		GoogleSearchPage.textbox_search(driver).sendKeys("automation steps");
		
		GoogleSearchPage.button_search(driver).click();
		
		//driver.findElement(By.name("btnK")).click();
		//driver.findElement(By.name("btnK")).sendKeys(Keys.RETURN);
		
		System.out.println("Test completed");
		
		
		
	}

}
