package pages;

//package test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;



public class ContactUs {
	
	static WebDriver driver = null;
	
	@BeforeTest
	public void setUpTest() {
		
		String projectPath = System.getProperty("user.dir");
	    System.setProperty("webdriver.chrome.driver", projectPath+"\\drivers\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
    
	@Test 
	public void test1() throws Exception {
		
        driver.get("https://dev-qa.konapay.net:10444/");
    	
    	Thread.sleep(5000);
    	
		driver.manage().window().maximize();
		
		Thread.sleep(5000);
		
		
		
		//clicking on Resources
    	driver.findElement(By.xpath("/html/body/div[1]/header/div/nav/ul/li[3]/a")).click();
    	
    	Thread.sleep(5000);
    	
    	//clicking on ContactUs from DropDown list
    	driver.findElement(By.xpath("/html/body/div[1]/header/div/nav/ul/li[3]/ul/li[3]/a")).click();
    	
    	Thread.sleep(5000);
    	
    	//clear the name 
    	//driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(3) > div:nth-child(1) > div:nth-child(3) > form:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > input:nth-child(1)")).clear();
    	
    	//Fill up name field
    	driver.findElement(By.xpath("/html/body/div/div[2]/div[3]/div/div[2]/form/div[1]/div[1]/div/div[2]/div/input")).sendKeys("wasif");
    	
    	Thread.sleep(2000);
    	
    	//Fill up Company field
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div[2]/form/div[1]/div[2]/div/div[2]/div/input")).sendKeys("KONA");
    	
    	Thread.sleep(2000);
    	
    	//Fill phone number field
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div[2]/form/div[1]/div[3]/div/div[2]/div/input")).sendKeys("01675308800");
    	
    	Thread.sleep(2000);
    	
    	//Fill up email field
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div[2]/form/div[1]/div[4]/div/div[2]/div/input")).sendKeys("wasif@dispostable.com");
    	
    	
    	Thread.sleep(3000);
    	
    	JavascriptExecutor jse = (JavascriptExecutor)driver;
    	jse.executeScript("window.scrollBy(0,500)");
    	
    	//Number of employees
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div[2]/form/div[1]/div[5]/div/div[2]/div[1]/div")).click();
    	
    	Thread.sleep(3000);
    	
    	//Select employees
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div[2]/form/div[1]/div[5]/div/div[2]/div[2]/div[3]/div/p")).click();
    	
    	Thread.sleep(3000);
    	
    	//Number of Funnel
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div[2]/form/div[1]/div[6]/div/div[2]/div[1]/div")).click();
    	
    	Thread.sleep(3000);
    	
    	//Select Funnel
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div[2]/form/div[1]/div[6]/div/div[2]/div[2]/div[3]/div/p")).click();
    	
    	Thread.sleep(3000);
    	
    	//scroll-down
    	jse.executeScript("window.scrollBy(0,500)");
    	
    	//Fill Title field
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div[2]/form/div[1]/div[7]/div/div[2]/div/input")).sendKeys("Title for automation");
    	
    	Thread.sleep(5000);
    	
    	//Fill message field
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div[2]/form/div[1]/div[8]/div/div[2]/div/textarea[1]")).sendKeys("Message for automation");
    	
    	Thread.sleep(5000);
    	
    	
    	//upload file
    	/*driver.findElement(By.xpath("")).sendKeys("C:\\Users\\enamul.haque\\Desktop\\8787.png");
    	
    	Thread.sleep(5000);*/
    	
    	jse.executeScript("window.scrollBy(0,500)");
    	
    	//CheckBox
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div[2]/form/div[1]/div[10]/div/div/label/span[1]/input")).click();
    	
    	Thread.sleep(3000);
    	
    	
    	//click on Contact us
    	//driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div[2]/form/div[2]/button")).click();	
       
    	/*String filePath = System.getProperty("user.dir") + "\\resources\\jsonFiles\\giantCombinedSurvey.json";
    	page.getInstance(SurveyPage.class).getChooseEventFile().sendKeys(filePath);*/
    	
        driver.switchTo().newWindow(WindowType.TAB);
    	driver.get("https://www.youtube.com/@edurekaIN");
    	
    	Thread.sleep(5000);
    	
    	driver.switchTo().newWindow(WindowType.WINDOW);
    	driver.get("https://admin-qa.konapay.net:10443/sign-in");
    	
    	Thread.sleep(5000);
    	
    	//admin-username
    	driver.findElement(By.xpath("/html/body/app-root/layout/empty-layout/div/div/auth-sign-in/div/div/div/form/mat-form-field[1]/div[1]/div[2]/div/input")).sendKeys("sys_admin");
    	
    	Thread.sleep(5000);
    	
    	//admin-password
        driver.findElement(By.xpath("/html/body/app-root/layout/empty-layout/div/div/auth-sign-in/div/div/div/form/mat-form-field[2]/div[1]/div[2]/div[1]/input")).sendKeys("Konasl@@123");
    	
    	Thread.sleep(5000);
    	
    	//admin-signIn
        driver.findElement(By.xpath("/html/body/app-root/layout/empty-layout/div/div/auth-sign-in/div/div/div/form/button/span[2]/span")).click();
    	
    	Thread.sleep(5000);
    	
    	//click-signOut
        driver.findElement(By.xpath("/html/body/app-root/layout/classic-layout/div/div[1]/div[2]/user/button/span[4]")).click();
    	
    	Thread.sleep(5000);
    	
    	//admin-signOut
        driver.findElement(By.xpath("/html/body/div/div[2]/div/div/div/button[4]/span/span")).click();
    	
    	Thread.sleep(5000);
    	
    	
	}	
    
}	
		
		
		
		
		
	
    
    
   
    


