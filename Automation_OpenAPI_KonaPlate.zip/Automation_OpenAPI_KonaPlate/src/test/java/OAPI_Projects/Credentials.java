package OAPI_Projects;

public class Credentials {

}
