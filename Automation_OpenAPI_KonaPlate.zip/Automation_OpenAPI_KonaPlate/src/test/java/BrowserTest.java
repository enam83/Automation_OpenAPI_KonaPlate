import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserTest {
	
	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.google.com/");
		
		driver.manage().window().maximize();
		
		
		driver.findElement(By.xpath("//*[@id=\"APjFqb\"]")).sendKeys("abcdef0077");
		
		List<WebElement> listofInputElements = driver.findElements(By.xpath("//input"));
		
		int count = listofInputElements.size();
		
		System.out.println("Count of Input elements = "+count);
		
		//WebElement textbox = driver.findElement(By.id("APjFqb"));
		//textbox.sendKeys("aabbcc");
		
		
		Thread.sleep(5000);		
		driver.quit();		
	}

}
